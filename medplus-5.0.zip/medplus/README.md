## MEDPLUS Codeigniter Work Files

### Inorder to work with this project you have to create necessary db for the project.

The database dump for the project is in 'DB_dump' folder. Download this file and import to phpMyAdmin.