
<div class="breadcrumbs  mb-4">
            <div class="breadcrumbs-inner">
                <div class="row m-0">
                    <div class="col-sm-4">
                        <div class="page-header float-left">
                            <div class="page-title">
                                <h1>Add Doctor</h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8">
                        <div class="page-header float-right">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li><a href="#">Dashboard</a></li>
                                    <li><a href="#">Doctor</a></li>
                                    <li class="active">Add Doctor</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

 <!-- BACK -->
          <div class="mb-md-4  ml-md-3   col-lg-8" >
                <a href="<?php echo base_url();?>admin/admin/doctor_view">
                  <button class="btn btn-success  pl-4 pr-4" onclick="">
                    <i class="fas fa-angle-left"></i>&nbsp Back
                  </button>
                </a>
            </div>

<!-- form -->
<div class="col-lg-8 ml-md-3  ">
    <div class="card">
        <div class="card-header">
            <strong>Doctor</strong> <br>Add Doctor
        </div>
        <!-- CARD HEADER -->
        <div class="card-body card-block">
            <form action="<?php echo base_url();?>admin/admin/add_doctor" method="POST" enctype="multipart/form-data" class="form-horizontal">
                <div class="col-12 p-3 mb-2 bg-danger text-white rounded">
                   <?php
                    // echo"hospital name from db";
                   ?> Patient's data were deleted. 
                </div>
             
            </form>
    </div>


    <!-- /card header -->
</div>
</div>

<script type='text/javascript'>
  // baseURL variable
  var baseURL= "<?php echo base_url();?>";

  $(document).ready(function(){

    // City change
    $('#selCountry').change(function(){
      var country = $(this).val();

      // AJAX request
      $.ajax({
        url:'<?php echo base_url('admin/adminModel/countryList')?>',
        method: 'post',
        data: {country: country},
        dataType: 'json',
        success: function(response){

          // Remove options
          $('#selCountry').find('option').not(':first').remove();
          $('#selState').find('option').not(':first').remove();
          $('#selCity').find('option').not(':first').remove();

          // Add options
          $.each(response,function(index,data)
          {
             $('#selCountry').append('<option value="'+data['country_id']+'">'+data['country_name']+'</option>');
          });
        }
     });
   });

   // Department change
   $('#selCountry').change(function(){
     var state = $(this).val();

     // AJAX request
     $.ajax({
       url:'<?php echo base_url('admin/adminModel/stateList');?>',
       method: 'post',
       data: {department: department},
       dataType: 'json',
       success: function(response){

         // Remove options
         $('#selState').find('option').not(':first').remove();

         // Add options
         $.each(response,function(index,data){
           $('#selState').append('<option value="'+data['state_id']+'">'+data['state_name']+'</option>');
         });
       }
    });
  });


  $('#selState').change(function(){
    var state = $(this).val();

    // AJAX request
    $.ajax({
      url:'<?php echo base_url('admin/adminModel/cityList')?>',
      method: 'post',
      data: {department: department},
      dataType: 'json',
      success: function(response){

        // Remove options
        $('#selCity').find('option').not(':first').remove();

        // Add options
        $.each(response,function(index,data){
          $('#selCity').append('<option value="'+data['city_id']+'">'+data['city_name']+'</option>');
        });
      }
   });
 });

 });
 </script>
